# Django Auth Project

A full-featured authentication system with a polished dark-themed Bootstrap 5 UI.

## Features
- User registration with email, first/last name
- Login / Logout with session management
- Profile page with editable fields
- Dashboard with account stats
- Django Admin panel
- SQLite3 database (zero config)
- CSRF protection on all forms
- Bootstrap 5 responsive design

## Project Structure
```
authproject/
├── authproject/        # Project config
│   ├── settings.py
│   └── urls.py
├── accounts/           # Auth app
│   ├── views.py
│   ├── forms.py
│   └── urls.py
├── templates/
│   ├── base.html
│   ├── home.html
│   ├── dashboard.html
│   └── accounts/
│       ├── login.html
│       ├── register.html
│       └── profile.html
├── db.sqlite3          # SQLite database
└── manage.py
```

## Setup & Run

```bash
# 1. Install dependencies
pip install django

# 2. Apply migrations (already done)
python manage.py migrate

# 3. Create admin superuser (optional)
python manage.py createsuperuser

# 4. Run the development server
python manage.py runserver

# 5. Open in browser
# http://127.0.0.1:8000/
```

## URLs
| URL | Description |
|-----|-------------|
| `/` | Home page |
| `/accounts/register/` | Registration |
| `/accounts/login/` | Login |
| `/accounts/logout/` | Logout (POST) |
| `/accounts/profile/` | Edit profile (auth required) |
| `/dashboard/` | Dashboard (auth required) |
| `/admin/` | Django admin |
